<!-- Main Header -->
      <header class="main-header">

        <!-- Logo -->
        <a href="#" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>D</b>CS</span>
              
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg">
              
            <b>Develop</b>@lang('home.company_name')</span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
           
                <li>
                  <a href="{{URL::to('/').'/locale/ar'}}" style="display: inline-block">
                        @lang('home.arabic')
                  </a>
                  <a href="{{URL::to('/').'/locale/en'}}" style="display: inline-block">
                        @lang('home.english')
                  </a>
                </li>
              
              <!-- User Account Menu -->
              <li class="dropdown user user-menu">
                <!-- Menu Toggle Button -->
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <!-- The user image in the navbar-->
                  @if(\Auth::user()->logo != NULL)
                  <img src="{{ asset('public/'.\Auth::user()->logo) }}" class="user-image" alt="User Image">
                  @else
                  <img src="{{ asset('adminstyle/dist/img/user2-160x160.jpg') }}" class="user-image" alt="User Image">
                  @endif
                  <!-- hidden-xs hides the username on small devices so only the image appears. -->
                  <span class="hidden-xs">{{ \Auth::user()->name }}</span>
                </a>
                
                <ul class="dropdown-menu">
                  <!-- The user image in the menu -->
                  <li class="user-header">
                    @if(\Auth::user()->logo != NULL)
                    <img src="{{ asset('public/'.\Auth::user()->logo) }}" class="img-circle" alt="User Image">
                    @else
                    <img src="{{ asset('adminstyle/dist/img/user2-160x160.jpg') }}" class="img-circle" alt="User Image">
                    @endif
                    <p>
                     {{ \Auth::user()->name }}
                    </p>
                  </li>
                  
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="{{ route('user.show')}}" class="btn btn-primary btn-flat">الصفحة الشخصية</a>
                    </div>
                    <div class="pull-right">
                      <a href="{{ route('userLogout') }}" class="btn btn-danger btn-flat">تسجيل الخروج</a>
                    </div>
                  </li>
                </ul>
              </li>
              </ul>
              </div>
        </nav> 
           <? $i=0;?>
            <!-- Sidebar Menu -->
          <ul class="nav nav-tabs">
            <li style="font-size: 14px; font-weight: bold;" class="header text-center">@lang("home.menu")</li>
            <!-- Optionally, you can add icons to the links -->
            
            <li class="dropdown active">
                <a style="font-size: 13px; font-weight: bold;" href="{{ route('home') }}"><i class="fa fa-tachometer"></i> <span>@lang('home.control')</span> </a>
            </li>

             @foreach(\Auth::user()->groups as $usergroup)   <!-- user Groups -->
              @foreach($usergroup->group->permissions as $permission)   <!-- group permissions -->
                @if((($permission['add'] == 1) || ($permission['update'] == 1) || ($permission['delete'] == 1))  || ($permission['view'] == 1)  )
                
                @if($permission->menus->menus->count() > 0  )
                      <!-- inside menu -->
                      <?php $active = "";  ?>
                      @foreach($permission->menus->menus as $insidemenu)
                          @if(isset($menuid) && $menuid == $insidemenu['id'] )
                            <?php $active = "active";  ?>
                          @endif
                      @endforeach
                        <li class="dropdown <?php if( isset($active) ){ echo $active; }?>">
                          <?php $active = "";  ?>
                              @if(Session::has("locale") && Session::get("locale")=="ar" )
                                <a class="dropdown-toggle"
                                data-toggle="dropdown" style="font-size: 13px; font-weight: bold;" 
                                href="#">
                              <i class="{{ $permission->menus['icon'] }}"></i> 
                              <span>{{ $permission->menus['name'] }} </span>
                              <i class="fa fa-angle-left pull-left"></i></a>
                              @else
                                <a class="dropdown-toggle"
                                data-toggle="dropdown" style="font-size: 13px; font-weight: bold;" 
                                href="#">
                                <i class="{{ $permission->menus['icon'] }}"></i> <span>{{ $permission->menus['name_en'] }} </span> <i class="fa fa-angle-left fa-angle-right pull-right"></i></a>
                              @endif
                              <ul class="dropdown-menu" >
                                <?php $active = "";  ?>
                              @foreach($permission->menus->menus as $insidemenu)
                                @if(isset($menuid) && $menuid == $insidemenu['id'] )
                                  <?php $active = "active";  ?>
                                @endif
                                  
                                <?php
                                $has_per=\App\Http\Controllers\MenuController::check_menue($insidemenu['id']);
                                ?>
                                @if($has_per==1) 
                                  @if(Session::has("locale") && Session::get("locale")=="ar")
                                  <li class=" dropdown <?php if( isset($active) ){ echo $active; }?>"><a  style="font-weight: bold;font-size: 12px; margin-right: 20px;"
                                  href="{{ route($insidemenu['url'],$insidemenu['id']) }}"><i class="{{ $insidemenu['icon'] }}"></i> <span>{{ $insidemenu['name'] }}  </span></a>
                                  </li> 
                                  @else
                                  <li class=" dropdown <?php if( isset($active) ){ echo $active; }?>">
                                  <a  style="font-weight: bold;font-size: 12px; margin-right: 20px;" 
                                    href="{{ route($insidemenu['url'],$insidemenu['id']) }}">
                                    <i class="{{ $insidemenu['icon'] }}"></i> <span>{{ $insidemenu['name_en'] }}  </span></a>
                                  </li>
                                  @endif
                              @endif
                              <?php $active = "";  ?>
                              @endforeach
                </ul>
            </li>  <!-- end of comp owner requestes -->
                    @endif  <!-- end if of add or update or delete -->
                      @endif 
        @endforeach  <!-- end of group permissions -->
            <li class="dropdown">
                <a class="dropdown-toggle"
                  data-toggle="dropdown"
                  href="#">
                    Others Menu
                    <b class="caret"></b>
                  </a>
                <ul class="dropdown-menu">
               
              @foreach($usergroup->group->permissions as $permission)   <!-- group permissions -->
                @if((($permission['add'] == 1) || ($permission['update'] == 1) || ($permission['delete'] == 1))  || ($permission['view'] == 1)  )
            
               <!-- main menu -->
                @if($permission->menus['parent_id'] == NULL && $permission->menus['url'] != NULL)
                 <?php $active = "";
                   //dd($usergroup->group->permissions);
                 ?>
                  @if( isset($menuid) && $permission->menus['id'] == $menuid)
                      <?php $active = "active"; ?>
                  @endif
                  <li class="dropdown <?php if( isset($active) ){ echo $active; }?>">
                    <?php $active = "";?>
                    @if(Session::has("locale") && Session::get("locale")=="ar")
                    <a  style="font-size: 13px; font-weight: bold;" href="{{ route($permission->menus['url'],$permission->menus['id']) }}">
                    <i class="{{ $permission->menus['icon'] }}"></i> <span>{{ $permission->menus['name'] }}</span> <i class=" pull-right"></i></a>
                    @else
                    <a style="font-size: 13px; font-weight: bold;" href="{{ route($permission->menus['url'],$permission->menus['id']) }}">
                    <i class="{{ $permission->menus['icon'] }}"></i>
                      <span>{{ $permission->menus['name_en'] }}</span> <i class=" pull-right"></i></a>
                    @endif
                  </li>
                  @endif
                 @endif  
          @endforeach 
           </ul>
              </li>
        @endforeach  <!-- end of user Groups -->
          </ul><!-- /.sidebar-menu -->
              </header>