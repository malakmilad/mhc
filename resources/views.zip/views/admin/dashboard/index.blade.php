@extends('admin.layouts.master')
@section('pagetitle') لوحة التحكم @endsection

<style>
    .charts { margin-bottom:20px; }
    .charts canvas { margin-bottom:40px; } 
</style>

@section('contentheader') 
 <section class="content-header text-right">
	  <h1>
	    لوحة التحكم
	    <small>يمكنك اضافة و تعديل و حذف لوحة التحكم من هنا</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="#"><i class="fa fa-dashboard"></i> لوحة التحكم </a></li>
	    <li class="active">لوحة التحكم</li>
	  </ol>
    <br>
    <br>
    <br>
    <br>

   <!-- <a href="{{ route('sheet.allsheets',30) }}" class="btn btn-primary btn-lg" role="button" >All Clients</a>
    <a href="{{ route('timetable.alltasks',31) }}" class="btn btn-primary btn-lg" role="button" >Orders</a>
    <a href="{{ route('timetable.alltasks',31) }}" class="btn btn-primary btn-lg" role="button" >Income</a>-->
<ul class="thumbnails list-inline" style="text-align:center;align-items: center;justify-content: center;">
  <li class="col-6-md" style="text-align:center;align-items: center;justify-content: center;width:290;height:300;">
    <a href="{{ route('sheet.create',30) }}" >
      <div style="width:250;  background-color: #3c8bdc;    color: #fff;">
        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="users" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512" class="svg-inline--fa fa-users fa-w-20 fa-5x"><path fill="currentColor" d="M96 224c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm448 0c35.3 0 64-28.7 64-64s-28.7-64-64-64-64 28.7-64 64 28.7 64 64 64zm32 32h-64c-17.6 0-33.5 7.1-45.1 18.6 40.3 22.1 68.9 62 75.1 109.4h66c17.7 0 32-14.3 32-32v-32c0-35.3-28.7-64-64-64zm-256 0c61.9 0 112-50.1 112-112S381.9 32 320 32 208 82.1 208 144s50.1 112 112 112zm76.8 32h-8.3c-20.8 10-43.9 16-68.5 16s-47.6-6-68.5-16h-8.3C179.6 288 128 339.6 128 403.2V432c0 26.5 21.5 48 48 48h288c26.5 0 48-21.5 48-48v-28.8c0-63.6-51.6-115.2-115.2-115.2zm-223.7-13.4C161.5 263.1 145.6 256 128 256H64c-35.3 0-64 28.7-64 64v32c0 17.7 14.3 32 32 32h65.9c6.3-47.4 34.9-87.3 75.2-109.4z" class=""></path></svg>
        <h1 style="text-align:center;">Add Client</h1> 
      </div>
    </a>
  </li>
  <li class="col-6-md" style="text-align:center;align-items: center;justify-content: center;width:290;height:300;">
    <a href="{{ route('timetable.create',31) }}" >
      <div style="width:250;   background-color: #3c8bdc;    color: #fff;">
        <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="file-invoice-dollar" class="svg-inline--fa fa-file-invoice-dollar fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9zm-153 31V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zM64 72c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8V72zm0 80v-16c0-4.42 3.58-8 8-8h80c4.42 0 8 3.58 8 8v16c0 4.42-3.58 8-8 8H72c-4.42 0-8-3.58-8-8zm144 263.88V440c0 4.42-3.58 8-8 8h-16c-4.42 0-8-3.58-8-8v-24.29c-11.29-.58-22.27-4.52-31.37-11.35-3.9-2.93-4.1-8.77-.57-12.14l11.75-11.21c2.77-2.64 6.89-2.76 10.13-.73 3.87 2.42 8.26 3.72 12.82 3.72h28.11c6.5 0 11.8-5.92 11.8-13.19 0-5.95-3.61-11.19-8.77-12.73l-45-13.5c-18.59-5.58-31.58-23.42-31.58-43.39 0-24.52 19.05-44.44 42.67-45.07V232c0-4.42 3.58-8 8-8h16c4.42 0 8 3.58 8 8v24.29c11.29.58 22.27 4.51 31.37 11.35 3.9 2.93 4.1 8.77.57 12.14l-11.75 11.21c-2.77 2.64-6.89 2.76-10.13.73-3.87-2.43-8.26-3.72-12.82-3.72h-28.11c-6.5 0-11.8 5.92-11.8 13.19 0 5.95 3.61 11.19 8.77 12.73l45 13.5c18.59 5.58 31.58 23.42 31.58 43.39 0 24.53-19.05 44.44-42.67 45.07z"></path></svg> 
        <h1 style="text-align:center;">Add Operation</h1> 
      </div>
    </a>
  </li>
<!--  <li class="span4 justify-content-end" style="text-align:center;align-items: center;justify-content: center;width:270;height:260;">
    <a href="{{ route('timetable.alltasks',31) }}" >
      <div style="width:230;height:260;text-align:center;   background-color: #3c8bdc;    color: #fff;">
     <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="hand-holding-usd" class="svg-inline--fa fa-hand-holding-usd fa-w-18" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M271.06,144.3l54.27,14.3a8.59,8.59,0,0,1,6.63,8.1c0,4.6-4.09,8.4-9.12,8.4h-35.6a30,30,0,0,1-11.19-2.2c-5.24-2.2-11.28-1.7-15.3,2l-19,17.5a11.68,11.68,0,0,0-2.25,2.66,11.42,11.42,0,0,0,3.88,15.74,83.77,83.77,0,0,0,34.51,11.5V240c0,8.8,7.83,16,17.37,16h17.37c9.55,0,17.38-7.2,17.38-16V222.4c32.93-3.6,57.84-31,53.5-63-3.15-23-22.46-41.3-46.56-47.7L282.68,97.4a8.59,8.59,0,0,1-6.63-8.1c0-4.6,4.09-8.4,9.12-8.4h35.6A30,30,0,0,1,332,83.1c5.23,2.2,11.28,1.7,15.3-2l19-17.5A11.31,11.31,0,0,0,368.47,61a11.43,11.43,0,0,0-3.84-15.78,83.82,83.82,0,0,0-34.52-11.5V16c0-8.8-7.82-16-17.37-16H295.37C285.82,0,278,7.2,278,16V33.6c-32.89,3.6-57.85,31-53.51,63C227.63,119.6,247,137.9,271.06,144.3ZM565.27,328.1c-11.8-10.7-30.2-10-42.6,0L430.27,402a63.64,63.64,0,0,1-40,14H272a16,16,0,0,1,0-32h78.29c15.9,0,30.71-10.9,33.25-26.6a31.2,31.2,0,0,0,.46-5.46A32,32,0,0,0,352,320H192a117.66,117.66,0,0,0-74.1,26.29L71.4,384H16A16,16,0,0,0,0,400v96a16,16,0,0,0,16,16H372.77a64,64,0,0,0,40-14L564,377a32,32,0,0,0,1.28-48.9Z"></path></svg>
     <h1 style="text-align:center;">Income</h1> 
      </div>
    </a>
  </li>-->
</ul>
 </section>
@endsection
@section('main-content')
{{-- <section class="content">
       <form  method="post">   
             {{ csrf_field() }}       
    <div class="charts">
        <div class="row">
             <div class="col-md-6">
                <canvas id="myChart0"></canvas>
             </div>
             <div class="col-md-6">
                <canvas id="myChart1"></canvas>
            </div>  
            <div class="col-md-6">
                <canvas id="myChart2"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="myChart3"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="myChart4"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="myChart5"></canvas>
            </div>
            <div class="col-md-6">
                <canvas id="myChart6"></canvas>
            </div>
        </div>
     --}}
  <!-- <div class="row">
             
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>{{ $allsheets->count() }}</h3>
              <p>كل العملاء الحاليين</p>
              @if( \Auth::user()->type == 1 )
              @foreach($allsheetsfilteratio as $counts)
                {{ $counts->first()->userfun['name'] }} - {{ $counts->count() }} <br>
              @endforeach
              @endif
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>{{ $allinterestes->count() }}</h3>
              <p>كل العملاء المهتمين</p>
              @if( \Auth::user()->type == 1 )
              @foreach($allinterstedpeople as $counts)
                {{ $counts->first()->userfun['name'] }} - {{ $counts->count() }} <br>
              @endforeach
              @endif
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
             
              <h3> @if( \Auth::user()->type == 1)
                    {{ $alltodaysheets ->count() }}
                   @elseif(\Auth::user()->type == 0)
                    <?php $ident = 0; ?>
                    @foreach($todayshhet as $counts)
                     @foreach($counts as $usernameandcounts)  
                     @if( $usernameandcounts['user_id'] == \Auth::user()->id )
                        <?php $ident = $counts->count(); ?>
                     @endif
                     @endforeach  
                    @endforeach
                    {{ $ident }}
                   @endif
              </h3>
             
              <p>عملاء اليوم</p>
             @if( \Auth::user()->type == 1 )
              @foreach($todayshhet as $counts)
                {{ $counts->first()->userfun['name'] }} - {{ $counts->count() }} <br>
              @endforeach
             @endif
             
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>{{ $alltodaytimetables->count() }}</h3>
              <p>زيارات اليوم</p>
             @if( \Auth::user()->type == 1 )
              @foreach($useralltodaytimetables as $counts)
                {{ $counts->first()->user['name'] }} - {{ $counts->count() }} <br>
              @endforeach
             @endif
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
          </div>
        </div>
        
        <div class="col-lg-3 col-xs-6">
          <div class="small-box bg-green">
            <div class="inner">
              <h3>{{ $donemeeting->count() }}</h3>
              <p>عدد الزيارات الكلية التي تمت</p>
      {{--   @if( \Auth::user()->type == 1 )
          //    @foreach($userdonemeeting as $counts)
           //     {{ $counts->first()->user['name'] }} - {{ $counts->count() }} <br>
          //    @endforeach
	  //   @endif --}}
           <!-- </div>
            <div class="icon">
              <i class="fa fa-check"></i>
            </div>
          </div>
        </div>-->
{{--<div class="col-lg-3 col-xs-4">
          <div class="small-box bg-red">
            <div class="inner">
              <h3>{{ $allsheetsbyarea1->count() }}</h3>
              <p>عدد العملاء بالمدن</p>
               @if( \Auth::user()->type == 1 )
              @foreach($allsheetsbyarea1 as $counts)
                {{ $counts->first()->area['name'] }} - {{ $counts->count() }} <br>
              @endforeach
             @endif
            </div>
            <div class="icon">
              <i class="fa fa-times"></i>
            </div>
          </div>
        </div>--}}
     {{-- <div class="col-lg-3 col-xs-4">
          <div class="small-box bg-red">
            <div class="inner">
              <h3>{{ $deosnotmeeting->count() }}</h3>
              <p>عدد الزيارات الكلية التي لم تتم</p>
               @if( \Auth::user()->type == 1 )
              @foreach($userdeosnotmeeting as $counts)
                {{ $counts->first()->user['name'] }} - {{ $counts->count() }} <br>
              @endforeach
             @endif
            </div>
            <div class="icon">
              <i class="fa fa-times"></i>
            </div>
          </div>
        </div>--}}  
      
      <!--  <div class="col-lg-3 col-xs-4">
          <div class="small-box bg-black">
            <div class="inner">
              <h3>{{ $canceldmeeting->count() }}</h3>
              <p>عدد الزيارات الكلية التي تم الغائها</p>
               @if( \Auth::user()->type == 1 )
              @foreach($usercanceldmeeting as $counts)
                {{ $counts->first()->user['name'] }} - {{ $counts->count() }} <br>
              @endforeach
             @endif
            </div>
            <div class="icon">
              <i class="fa fa-times"></i>
            </div>
          </div>
        </div>
            
    </div> -->
     {{--  </form>
    <meta name="csrf-token" content="{{ csrf_token() }}" />--}}
 </section>
 <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
 <script>
     $(document).ready(function(){
         
        });
           var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var ctx = document.getElementById('myChart0').getContext('2d');
    var chart = new Chart(ctx, {
        type: 'line',
    
        // The data for our dataset
        data: {
            labels: ['gorgena', 'Admin', 'evon', 'Ahmed', 'Test', 'Eng.Edward', 'Noha'],
            datasets: [{
                label: 'عدد العملاء الحاليين {{ $allsheets->count() }}',
                backgroundColor: 'rgb(255, 99, 132)',
                borderColor: 'rgb(255, 99, 132)',
                data: [0, 10, 5, 2, 20, 30, 45]
            }]
        },
    
        // Configuration options go here
        options: {}
    });
    
    var ctx2 = document.getElementById('myChart1').getContext('2d');
    var myChart = new Chart(ctx2, {
        type: 'bar',
        data: {
            labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
            datasets: [{
                label: 'كل العملاء المهتمين {{ $allinterestes->count() }}',
                data: [12, 19, 3, 5, 2, 3],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    
    var ctx3 = document.getElementById('myChart2');
    var myPieChart = new Chart(ctx3, {
        type: 'pie',
            data: {
            labels: ['الكل','عملاء اليوم'],
            datasets: [{
                data: [90, 10],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)'
                ],
                borderWidth: 1
            }]
        },
    });
    
    var ctx4 = document.getElementById('myChart3');
    var myPieChart4 = new Chart(ctx4, {
        type: 'pie',
            data: {
            labels: ['الكل','زيارات اليوم '],
            datasets: [{
                data: [80, 20],
                backgroundColor: [
                    'rgba(156, 105, 249, 0.2)',
                    'rgba(54, 162, 235, 0.2)'
                ],
                borderColor: [
                   'rgba(156, 105, 249, 1)',
                    'rgba(54, 162, 235, 1)'
                ],
                borderWidth: 1
            }]
        },
    });
    
    var ctx5 = document.getElementById('myChart4').getContext('2d');
    var myChart5 = new Chart(ctx5, {
        type: 'bar',
        data: {
            labels: ['Admin', 'Ahmed'],
            datasets: [{
                label: 'عدد الزيارات الكلية التى تمت',
                data: [12, 19],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
     // Split timestamp and data into separate arrays

    let labels = [], data1=[];
       $(document).ready(function(){
       $.ajax({

                            url: '../get_areas',
                            type: 'POST',
                            /* send the csrf-token and the input to the controller */
                            data: {_token: CSRF_TOKEN},
                            dataType: 'JSON',
                            /* remind that 'data' is the response of the AjaxController */
                            success: function (data) {
                              console.log(data.allsheetsbyarea);
                              for(let i=0;i<data.allsheetsbyarea.length;i++)
                              {
                                   console.log(data.allsheetsbyarea[i]['name']);
                                   labels.push(data.allsheetsbyarea[i]['name']);
                                   data1.push(data.allsheetsbyarea[i]['count']);  
                              }   
                               var ctx6 = document.getElementById('myChart5').getContext('2d');
                               var myChart6 = new Chart(ctx6, {
                                    type: 'bar',
                                      
                                    data: {
                                        labels:labels,
                                        datasets: [{
                                            label: 'عدد العملاء بالمدن {{ $allsheetsbyarea1->count() }}',
                                            backgroundColor: 'rgb(255, 99, 132)',
                                            borderColor: 'rgb(255, 99, 132)',
                                            data:data1
                                        }]
                                    
                                    },
                                    
                                    // Configuration options go here
                                    options: {}
                                });
                                        
                            }
           });
          });
  /*  for (const [area, count] of {{$allsheetsbyarea1}}) {
      labels.push(new Date(area.name));
      data.push(parseFloat(area.name));
    }*/
  /*@json($allsheetsbyarea1).forEach(function(packet) {
      labels.push(new Date(packet.name).formatMMDDYYYY());
      data.push(parseFloat(packet.name));
    });*/
    console.log(labels);
   
    var ctx7 = document.getElementById('myChart6').getContext('2d');
    var myChart7 = new Chart(ctx7, {
        type: 'bar',
        data: {
            labels: ['Ramy'],
            datasets: [{
                label: 'عدد الزيارات الكلية التى تم الغاؤها',
                data: [49],
                backgroundColor: [
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
    
</script>

@endsection